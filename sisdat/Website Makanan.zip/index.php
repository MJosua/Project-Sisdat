<html>
	<head>
		<title> Info Restoran GG</title>
		<link href="css/style.css" rel="stylesheet">
				<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

	</head>
<body style="margin:0;">
	<div class="sidebar">
   		 		
   		 	</div>
		<header id="top-header" >
			<div class="header">
				<h1> <a href="#" class="NamaToko"  > Info Restoran GG </a> </h1>
			</div>
			
			<hr class="line"><hr class="lineShading">
		</header>
				
		
		
		  <div id="hot-deal" class="section">		
						<a class="primary-btn hot-btn" href="RM"> Info Rumah Makan </a><br> 
						<a class="primary-btn hot-btn" href="logindulu.php"> Login</a> 
						<a class="primary-btn hot-btn" href="register.php"> Register</a> 
		</div> 
		<hr class="lineShading">	
		

</body>
<footer>
<hr class="lineShading">

<div class="footer1">
<h2><i style="margin-right:5px;margin-top:5px;"class="far fa-user-circle"></i> Yosua Prima Gultom</h2>
<h3><p ><font size="5">NPM : 140810170038 <br>UAS SISDAT<br></p></font>
</div>

<div class="footer2">
<h2><i style="margin-right:5px;margin-top:5px;" class="far fa-user-circle"></i> Husein Irfan</h2>
<h3><p ><font size="5"><i class="fab fa-wifi"></i>1408101700<br>UAS SISDAT<br></h3></font>
</div>




</footer>
<script>
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}


function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>
</html>

